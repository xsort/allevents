<!DOCTYPE html>
<html lang="en">
<head>
<style>
    html{
    background: url(img/bg.jpg) no-repeat center center fixed; 
    -webkit-background-size: cover;
    -moz-background-size: cover;
    -o-background-size: cover;
    background-size: cover;
}

.wrapper {
    height: 100%;
    width: 100%;
    text-align: center;
}

.center_image {
     height: 50%;
     width: auto;
     top:25%;
     left:25%;
     bottom: 25%;
     right: 25%;
     position: fixed;
     display: inline;
     /*margin-top:20%;*/
}

</style>
    <meta charset="UTF-8">
    <title>ALL EVENTS</title>
    <meta id="viewport" name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=.5, user-scalable=no">

    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="wrapper">
        <img src="img/img.png" alt="" class="center_image">
    </div>
</body>
</html>