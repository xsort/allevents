<div class="col-md-4 col-sm-4 col-xs-12">
    <div class="row">
        <a href="{{$data->slug}}/photo" class="instMenuItem filterBlock-0 c-bg-center" style="background-image: url(images/inst-menu-photo/photo.png);">
            <div class="c-bg-center" layout="column" layout-align="space-between stretch">
                <h3 class="instMenuTitle" layout="column" layout-align="end center" >Фото</h3>
                <span class="instMenuDescrShort">Lorem ipsum dolor sit amet, consectetur adipisicing elit. </span>
                <md-button>Подробнее</md-button>
            </div>
        </a>
    </div>
</div>
<div class="col-md-4 col-sm-4 col-xs-12">
    <div class="row">
        <a href="{{$data->slug}}/video" class="instMenuItem filterBlock-1 c-bg-center" style="background-image: url(images/inst-menu-photo/video.png);" >
            <div class="c-bg-center" layout="column" layout-align="space-between stretch">
                <h3 class="instMenuTitle" layout="column" layout-align="end center" >Видео</h3>
                <span class="instMenuDescrShort">Lorem ipsum dolor sit amet, consectetur adipisicing elit. </span>
                <md-button>Подробнее</md-button>
            </div>
        </a>
    </div>
</div>

<div class="col-md-4 col-sm-4 col-xs-12">
    <div class="row">
        <a href="{{$data->slug}}/menu" class="instMenuItem filterBlock-2 c-bg-center" style="background-image: url(images/inst-menu-photo/plan.png);">
            <div class="instMenuBlock-2 c-bg-center" layout="column" layout-align="space-between stretch" >
                <h3 class="instMenuTitle" layout="column" layout-align="end center" >Услуги</h3>
                <span class="instMenuDescrShort">Lorem ipsum dolor sit amet, consectetur adipisicing elit. </span>
                <md-button>Подробнее</md-button>
            </div>
        </a>
    </div>
</div>

<div class="col-md-4 col-sm-4 col-xs-12">
    <div class="row">
        <a href="{{$data->slug}}/menu" class="instMenuItem filterBlock-3 c-bg-center" style="background-image: url(images/inst-menu-photo/menu.png);">
            <div class="c-bg-center" layout="column" layout-align="space-between stretch">
                <h3 class="instMenuTitle" layout="column" layout-align="end center" >Цены</h3>
                <span class="instMenuDescrShort">Lorem ipsum dolor sit amet, consectetur adipisicing elit. </span>
                <md-button>Подробнее</md-button>
            </div>
        </a>
    </div>
</div>

<div class="col-md-4 col-sm-4 col-xs-12">
    <div class="row">
        <a href="{{$data->slug}}/promo" class="instMenuItem filterBlock-4 c-bg-center" style="background-image: url(images/inst-menu-photo/actii.png);">
            <div class=" c-bg-center" layout="column" layout-align="space-between stretch" >
                <h3 class="instMenuTitle" layout="column" layout-align="end center" >Акции</h3>
                <span class="instMenuDescrShort">Lorem ipsum dolor sit amet, consectetur adipisicing elit. </span>
                <md-button>Подробнее</md-button>
            </div>
        </a>
    </div>
</div>

{{--
<div class="col-md-4 col-sm-4 col-xs-12">
    <div class="row">
        <a href="{{$data->slug}}/interier" class="instMenuItem filterBlock-5 c-bg-center" style="background-image: url(images/inst-menu-photo/interier.png);">
            <div class=" c-bg-center" layout="column" layout-align="space-between stretch">
                <h3 class="instMenuTitle" layout="column" layout-align="end center" >Интерьер</h3>
                <span class="instMenuDescrShort">Lorem ipsum dolor sit amet, consectetur adipisicing elit. </span>
                <md-button>Подробнее</md-button>
            </div>
        </a>
    </div>
</div>
--}}