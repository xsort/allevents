@extends('admin.common.list',
    [
        'title'       =>  'Список пользователей ',
        'desc'        =>  'Пользователи сайта',
        'model'       =>  'users',
        'fields'      =>  ['name' => 'Логин '],
        'data'        =>  $data
    ]
)