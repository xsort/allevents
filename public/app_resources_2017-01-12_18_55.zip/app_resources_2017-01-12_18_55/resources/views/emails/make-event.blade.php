<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<b>Имя:</b> {{ $name }} <br/>
<b>Телефон:</b> {{ $phone }} <br/>
<b>Сообщение:</b> {{ $text }} <br/>