<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<b>Email:</b> {{ $clientEmail }} <br/>
