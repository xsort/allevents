<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
Объект {{ $product }} был изменен одним из менеджеров и ожидает вашего рассмотрения.

Контактные данные менеджера:
<b>Имя:</b> {{ $name }} <br/>
<b>Email:</b> {{ $email }} <br/>
<b>Телефон:</b> {{ $mobile }} <br/>