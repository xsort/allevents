<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<b>Имя:</b> {{ $name }} <br/>
<b>Email:</b> {{ $email }} <br/>
<b>Сообщение:</b> {{ $text }} <br/>